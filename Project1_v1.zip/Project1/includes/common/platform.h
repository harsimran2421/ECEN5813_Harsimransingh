/********************************************
 * *   Authors: Harsimransingh Bindra, Smitesh Modak
 * *   Date Edited: 10/01/2017
 * *
 * *   File: platform.h
 * *
 * *   Description: Header file for making the code platfrom independent
 * *
 * *
 * ********************************************************/
#ifndef PLATFORM_H_
#define PLATFORM_H_

#ifdef KL25Z
#define printf(...) 
#endif
#endif
