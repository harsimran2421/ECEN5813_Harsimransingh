#include <stdio.h>
#include "project1.h"
int main()
{
	#ifdef PROJECT1
		project1();
  	#endif
 }
