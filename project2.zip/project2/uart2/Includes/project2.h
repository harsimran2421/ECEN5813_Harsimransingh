#ifndef INCLUDES_PROJECT2_H_
#define INCLUDES_PROJECT2_H_

void project2();

#endif /* INCLUDES_PROJECT2_H_ */
