#include <stdio.h>

void project2(void);
